import LandingSection from "./LandingSection";
import Section from "../basic/Section";
import Gallery from "../basic/Gallery";
import Card from "../basic/Card";
import Featured from "./featured";

export default function Home() {
  return (
    <>
      <LandingSection />
      <Featured />
      <Section testId="gallery-section" margin="0 0 24px 0">
        <Card>
          <Gallery />
        </Card>
      </Section>
    </>
  );
}
